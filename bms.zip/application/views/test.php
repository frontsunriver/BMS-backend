

<!doctype html>
<html class=no-js lang="">
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
<head>
<meta charset=utf-8>

</head>
<body>
    <div class="wrapper">
        <form method="POST" enctype="multipart/form-data" action="/bms/home/importExcel">
			<input type="file" name="importexcel" id="importexcel"/>
			<input type="submit" value="submit" />
		</form>
    </div>			
</body>
</html>

